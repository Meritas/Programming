package main;

public interface Discountable {
	public void discount();

}
