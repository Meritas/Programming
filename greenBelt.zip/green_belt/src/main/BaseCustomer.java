package main;

public class BaseCustomer extends Customer {

	public BaseCustomer(String character, String name, String address,
			int annual_billing) {
		super(character, name, address, annual_billing);
		// TODO Auto-generated constructor stub
	}
	
}
